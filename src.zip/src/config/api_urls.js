export const ApiUrls = {
  baseUrl: 'https://api.punkapi.com/v2/',
  getBeers: 'beers/?{urlParameters}',
};
